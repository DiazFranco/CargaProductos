import java.util.Scanner;

public class Ventas {
    public static void main(String[] args) {


        Scanner scanner = new Scanner(System.in);
        String encargado;
        int numeroOrden;
        char continuar = 'y';


        System.out.println("Ingrese su nombre: ");
        encargado = scanner.nextLine();


        while (continuar == 'y') {

            System.out.println("Ingrese número de orden: ");
            numeroOrden = scanner.nextInt();

            // Se crean objetos producto
            Producto p1 = new Producto("Camisa", 2000.00);
            Producto p2 = new Producto("Pantalon", 2500.00);
            Producto p3 = new Producto("Remera", 1100.00);

            // Creamos un objeto Orden
            Orden orden1 = new Orden(encargado, numeroOrden);

            //Agregamos los productos a la orden
            orden1.agregarProductos(p1);
            orden1.agregarProductos(p2);
            orden1.agregarProductos(p3);

            orden1.verOrden();

            System.out.println("Desea agregar otra orden? (y/n)");
            continuar = scanner.next().charAt(0);

            if (continuar == 'y'){
                System.out.println("Ingrese número de orden: ");
                numeroOrden = scanner.nextInt();

                Orden orden2 = new Orden(encargado,numeroOrden);

                Producto p4 = new Producto("Zapatos", 5000.00);
                Producto p5 = new Producto("Cinturón", 1000.00);

                //Agregamos productos a la orden 2
                orden2.agregarProductos(p1);
                orden2.agregarProductos(p4);
                orden2.agregarProductos(p5);
                orden2.agregarProductos(p3);

                System.out.println("");
                orden2.verOrden();

                System.out.println("Desea agregar otra orden? (y/n)");
                continuar = scanner.next().charAt(0);

            } else {
                continuar = 'n';
                scanner.close();
            }
        }
    }

}
